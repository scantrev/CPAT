﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TRS_CPAT.Startup))]
namespace TRS_CPAT
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
