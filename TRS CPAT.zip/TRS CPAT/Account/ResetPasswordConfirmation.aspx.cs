﻿using System.Web.UI;

namespace TRS_CPAT.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}